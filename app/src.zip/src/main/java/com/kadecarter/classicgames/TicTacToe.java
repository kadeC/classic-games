package com.kadecarter.classicgames;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class TicTacToe extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tic_tac_toe);
    }
}
